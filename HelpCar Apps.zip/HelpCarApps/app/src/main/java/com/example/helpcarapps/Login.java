package com.example.helpcarapps;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Login extends AppCompatActivity {
    FirebaseAuth mAuth;
    ProgressBar progressBar;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mAuth = FirebaseAuth.getInstance();
        EditText emel = findViewById(R.id.emel);
        EditText katalaluan= findViewById(R.id.katalaluan);
        Button loginBtn = findViewById(R.id.loginBtn);
        progressBar = findViewById(R.id.progressBar);
        TextView registerNowBtn= findViewById(R.id.registerNowBtn);

        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                progressBar.setVisibility(View.VISIBLE);
                 String EmailTxt= emel.getText().toString();
                 String passwordtxt= katalaluan.getText().toString();

                if(EmailTxt.isEmpty() || passwordtxt.isEmpty()){
                    Toast.makeText(Login.this, "Sila masukkan nombor telefon atau katalaluan", Toast.LENGTH_SHORT).show();
                }

                mAuth.signInWithEmailAndPassword(EmailTxt, passwordtxt)
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(Task<AuthResult> task) {
                                progressBar.setVisibility(View.GONE);
                                if (task.isSuccessful()) {
                                    Toast.makeText(getApplicationContext(), "Login Successful",Toast.LENGTH_SHORT).show();
                                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                                    startActivity(intent);
                                    finish();
                                } else {

                                    Toast.makeText(Login.this, "Authentication failed.",
                                            Toast.LENGTH_SHORT).show();

                                }
                            }
                        });

            }
        });

        registerNowBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // open Register activity
                //startActivity(new Intent(Login.this,Register.class));
                Intent i = new Intent(Login.this, Register.class);
                startActivity(i);

            }
        });

    }

    public void registerbtn(View view) {
        Intent i = new Intent(Login.this, Register.class);
        startActivity(i);
    }
}