package com.example.helpcarapps;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class Register extends AppCompatActivity {

FirebaseAuth mAuth;
ProgressBar progressBar;






    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        mAuth= FirebaseAuth.getInstance();
        EditText name= findViewById(R.id.name);
        EditText emel= findViewById(R.id.email);
        EditText phone = findViewById(R.id.telefon);
        EditText password = findViewById(R.id.password);
        EditText comPassword = findViewById(R.id.compassword);

        Button registerBtn = findViewById(R.id.registerBtn);
        progressBar = findViewById(R.id.progressBar);
        TextView loginNowBtn = findViewById(R.id.loginNow);

        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference();

        registerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // get data from EditTexts into String variables
                progressBar.setVisibility(View.VISIBLE);
                String nameTxt = name.getText().toString();
                String EmailTxt = emel.getText().toString();
                String phoneTxt = phone.getText().toString();
                String passwordTxt= password.getText().toString();
                String comPasswordTxt= comPassword.getText().toString();

                // check if user fill all the fields before sending data to firebase
                if (nameTxt.isEmpty() || EmailTxt.isEmpty() || phoneTxt.isEmpty() || passwordTxt.isEmpty()){
                    Toast.makeText(Register.this,"Sila isikan maklumat", Toast.LENGTH_SHORT).show();
                    return;
                }

                //check if passwords are matching with each other
                // if not matching with each other then show a toast message
                else if(!passwordTxt.equals((comPasswordTxt))){
                   Toast.makeText(Register.this,"Kata Laluan tidak sama", Toast.LENGTH_SHORT).show();
                   return;

                }
                else {


                            mAuth.createUserWithEmailAndPassword(EmailTxt, passwordTxt)
                                    .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                                        @Override
                                        public void onComplete(Task<AuthResult> task) {
                                            progressBar.setVisibility(View.GONE);
                                              if (task.isSuccessful()) {
                                                  databaseReference.child("users").addListenerForSingleValueEvent(new ValueEventListener() {
                                                      @Override
                                                      public void onDataChange(DataSnapshot snapshot) {
                                                          databaseReference.child("users").child(phoneTxt).child("name").setValue(nameTxt);
                                                          databaseReference.child("users").child(phoneTxt).child("emel").setValue(EmailTxt);
                                                          databaseReference.child("users").child(phoneTxt).child("password").setValue(passwordTxt);

                                                          //show a success message then finish the activity.
                                                          Toast.makeText(Register.this, "User Registered Successfully", Toast.LENGTH_SHORT).show();
                                                          finish();
                                                      }

                                                      @Override
                                                      public void onCancelled(DatabaseError error) {

                                                      }
                                                  });



                                                Toast.makeText(Register.this, "Authentication Successful.",
                                                        Toast.LENGTH_SHORT).show();

                                            } else {
                                                // If sign in fails, display a message to the user.

                                                Toast.makeText(Register.this, "Authentication failed.",
                                                        Toast.LENGTH_SHORT).show();

                                            }

                                                    }
                        });



                   // Toast.makeText(Register.this, "Test", Toast.LENGTH_SHORT).show();
                }

            }

        });
        loginNowBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                finish();
            }
        });


    }
}